package com.senla.testproject.services;
import com.senla.testproject.entities.ships.*;
import com.senla.testproject.entities.containers.*;

public class ShipService {
    //private ArrayList shiplist = new ArrayList();
    private int shipid = 100;

    public CargoShip createCargoShip(int largeContainers, int smallContainers) {
        //Random randInt = new Random();
        //int shipid = randInt.nextInt(200 - 100) + 100;
        Deck firstdeck = new Deck();
        Deck seconddeck = new Deck();

        for (int i = 0; i < largeContainers; i++) {
            Cont1000L largeContainer = new Cont1000L();
            if (!firstdeck.getIsFullLoaded()) {
                firstdeck.grabCargo(largeContainer);
            } else {
                seconddeck.grabCargo(largeContainer);
            }
        }

        for (int i = 0; i < smallContainers; i++) {
            Cont450L smallContainer = new Cont450L();
            if (!firstdeck.getIsFullLoaded()) {
                firstdeck.grabCargo(smallContainer);
            } else {
                seconddeck.grabCargo(smallContainer);
            }
        }
        //CargoShip cargoShip = new CargoShip(shipid, firstdeck, seconddeck);
        CargoShip cargoShip = new CargoShip(shipid, firstdeck, seconddeck);
        shipid++;
        return cargoShip;
    }
}
