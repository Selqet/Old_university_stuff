package com.senla.testproject.services;

import com.senla.testproject.entities.places.Ocean;
import com.senla.testproject.entities.places.Port;
import com.senla.testproject.entities.ships.CargoShip;

import java.util.Map;

public class PortService {
    Port port = Port.getInstance();
    Ocean ocean = Ocean.getInstance();

    public int getStoragedWater() {
        return port.getStoragedWater();
    }

    public void locateShip(CargoShip ship, String location) {
        if (location.equals("Port")) {
            port.addShip(ship);
        } else {
            ocean.addShip(ship);
        }
    }

    public int getAmountOfShips() {
        return port.getAmountofShips();
    }

    public Map<Integer, CargoShip> getShipsInThePort() {
        return port.getShipList();
    }

    public Map<Integer, CargoShip> getShipsInTheOcean() {
        return ocean.getShipList();
    }

    public boolean demolishShip(int id) {
        return port.demolishShip(id);
    }

    public boolean dockShip(int id) {
        CargoShip ship = ocean.dockShip(id);
        if (ship == null) {
            return false;
        } else {
            port.addShip(ship);
            return true;
        }
    }
}
