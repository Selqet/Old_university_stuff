package com.senla.testproject.entities.containers;

public class Cont450L {
    boolean isEmpty = false;
    public Cont450L() {
        System.out.println("Bim!");
    }

    public int unloadContainer() {
        if (isEmpty) {
            isEmpty = true;
            return 450;
        } else {
            return 0;
        }
    }
}
