package com.senla.testproject.entities.containers;

public class Cont1000L {
    boolean isEmpty = false;

    public Cont1000L() {
        System.out.println("Bam!");
    }

    public int unloadContainer() {
        if (isEmpty) {
            isEmpty = true;
            return 1000;
        } else {
            return 0;
        }
    }
}
