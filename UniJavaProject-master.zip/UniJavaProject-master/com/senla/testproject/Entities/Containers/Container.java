package com.senla.testproject.entities.containers;

public class Container {
    boolean isEmpty = false;

    public int unloadContainer() {
        return 0;
    }
}
