package com.senla.testproject.entities.ships;
import  com.senla.testproject.entities.containers.*;
import java.util.ArrayList;

public class Deck {
    private boolean isFullLoaded = false;
    private ArrayList cargo = new ArrayList<Container>();

    public void grabCargo (Cont450L first, Cont450L second) {
        cargo.add(first);
        cargo.add(second);
        isFullLoaded = true;
    }

    public void grabCargo (Cont1000L first) {
        cargo.add(first);
        isFullLoaded = true;
    }

    public void grabCargo (Cont450L first) {
        if (cargo.isEmpty()){
            cargo.add(first);
        } else {
            cargo.add(first);
            isFullLoaded = true;
        }
    }

    public boolean getIsFullLoaded() {
        return isFullLoaded;
    }
}
