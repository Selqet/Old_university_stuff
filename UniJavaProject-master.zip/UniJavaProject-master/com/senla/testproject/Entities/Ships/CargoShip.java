package com.senla.testproject.entities.ships;

public class CargoShip extends Ship {
    Deck firstdeck;
    Deck seconddeck;

    public CargoShip (int inputid, Deck first, Deck second) {
        super(inputid);
        this.firstdeck = first;
        this.seconddeck = second;
    }

    public String getShipClass() {
        return "Medium Cargo ship";
    }
}
