package com.senla.testproject.entities.ships;

public class Ship {
    private int id;

    public Ship(int inputid) {
        this.id = inputid;
    }
    public int getid() {
        return id;
    }
}
