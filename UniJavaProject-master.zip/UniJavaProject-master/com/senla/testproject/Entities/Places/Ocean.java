package com.senla.testproject.entities.places;
import com.senla.testproject.entities.ships.CargoShip;
import java.util.*;

public class Ocean {
    private static Ocean instance = null;
    private Map<Integer, CargoShip> shiplist = new TreeMap<Integer, CargoShip>();

    private Ocean() {

    }

    public static Ocean getInstance() {
        if (instance == null) {
            instance = new Ocean();
        }
        return  instance;
    }

    public void addShip(CargoShip ship) {
        shiplist.put(ship.getid(), ship);
    }

    public Map<Integer, CargoShip> getShipList() {
        return shiplist;
    }

    public CargoShip dockShip(int id) {
        if (shiplist.containsKey(id)) {
            CargoShip ship = shiplist.get(id);
            shiplist.remove(id);
            return ship;
        } else {
            return null;
        }
    }
}
