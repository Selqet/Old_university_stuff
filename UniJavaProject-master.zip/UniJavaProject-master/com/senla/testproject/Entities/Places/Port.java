package com.senla.testproject.entities.places;

import com.senla.testproject.entities.ships.CargoShip;
import java.util.*;

public class Port {
    private int storagedWater;
    private static Port instance = null;
    private Map<Integer, CargoShip> shiplist = new TreeMap<Integer, CargoShip>();

    private Port() {

    }

    public static Port getInstance() {
        if (instance == null) {
            instance = new Port();
        }

        return instance;
    }

    public int getStoragedWater() {
        return storagedWater;
    }

    public void addShip(CargoShip ship) {
        shiplist.put(ship.getid(), ship);
    }

    public int getAmountofShips() {
        return shiplist.size();
    }

    public Map<Integer, CargoShip> getShipList() {
        return shiplist;
    }

    public boolean demolishShip(int id) {
        if (shiplist.containsKey(id)) {
            shiplist.remove(id);
            return true;
        } else {
            return false;
        }
    }
}
