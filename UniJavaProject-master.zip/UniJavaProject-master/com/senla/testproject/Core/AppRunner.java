package com.senla.testproject.core;
import  com.senla.testproject.ui.*;
                //Класс запускает приложение
public class AppRunner {
    public static void main(String[] args) {
        ConsoleInitializer console = new ConsoleInitializer();
        console.run();
    }
}
