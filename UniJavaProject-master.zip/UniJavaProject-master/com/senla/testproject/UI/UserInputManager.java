package com.senla.testproject.ui;

import com.senla.testproject.entities.ships.CargoShip;
import com.senla.testproject.services.PortService;
import com.senla.testproject.services.ShipService;

import java.util.Map;
import java.util.Scanner;

public class UserInputManager {
    ShipService shipService = new ShipService();
    PortService portService = new PortService();

    public String processUserInput(int command) {
        switch (command) {
            case 1:
                buildShip();
                return "cool";
            case 2:
                printStoragedWater();
                return "cool";
            case 3:
                printShipsInThePort();
                return "cool";
            case 4:
                printSailingShips();
                return "cool";
            case 5:
                dockShip();
                return "cool";
            case 6:
                demolishShip();
                return "cool";
            case 9:
                System.out.println("\nEnter number of the command: \n1. Create ship\n2. Check storaged water\n3. Print docked ships\n4. Print sailing ships\n5. Dock ship\n6. Demolish ship\n9. Print help\n0. Exit program");
                return "help";
            case 0:
                return "exit";
            default:
                System.out.println("\nIncorrect command");
                return "cool";
        }
    }

    private void buildShip() {
        System.out.println("\nEnter location of the ship (Ocean/Port): ");
        Scanner in = new Scanner(System.in);
        String locinput = in.nextLine();

        if (locinput.equals("Ocean") || (locinput.equals("Port") && portService.getAmountOfShips() < 10)) {
            System.out.println("Enter amount of the containers. First large, then small. (example:'1 2'): ");
            String input = in.nextLine();
            int largeContainers = Character.getNumericValue(input.charAt(0));
            int smallContainers = Character.getNumericValue(input.charAt(2));

            if (largeContainers > 2 || largeContainers < 0 || smallContainers > 4 || smallContainers < 0 || (largeContainers == 2 && smallContainers > 0) || (largeContainers == 1 && smallContainers > 2)) {
                System.out.println("Incorrect amount of containers!");
            } else {
                CargoShip ship = shipService.createCargoShip(largeContainers, smallContainers);
                portService.locateShip(ship, locinput);
            }
        } else {
            if (locinput.equals("Port")){
                System.out.println("Too many ships in the port!");
            } else {
                System.out.println("Incorrect location");
            }
        }
    }

    private void printStoragedWater() {
        System.out.printf("\nThere are %s litres of water in the port\n", portService.getStoragedWater());
    }

    private void printShipsInThePort() {
        Map<Integer, CargoShip> shiplist = portService.getShipsInThePort();
        System.out.print("\nList of the ships in the port: ");
        for (Map.Entry <Integer, CargoShip> ship: shiplist.entrySet()) {
            System.out.printf("\nID: %s Class: %s", ship.getKey(), ship.getValue().getShipClass());
        }
        System.out.println();
    }

    private void printSailingShips() {
        Map<Integer, CargoShip> shiplist = portService.getShipsInTheOcean();
        System.out.print("\nList of the ships in the ocean: ");
        for (Map.Entry <Integer, CargoShip> ship: shiplist.entrySet()) {
            System.out.printf("\nID: %s Class: %s", ship.getKey(), ship.getValue().getShipClass());
        }
        System.out.println();
    }

    private void demolishShip() {
        Scanner in = new Scanner(System.in);
        System.out.println("\nEnter ship's id: ");
        String idinput = in.nextLine();
        int id = Integer.parseInt(idinput);

        boolean result = portService.demolishShip(id);
        if (result) {
            System.out.println("Ship has been demolished");
        } else {
            System.out.println("Ship not found");
        }
    }

    private void dockShip() {
        Scanner in = new Scanner(System.in);
        System.out.println("\nEnter ship's id: ");
        String idinput = in.nextLine();
        int id = Integer.parseInt(idinput);

        boolean result = portService.dockShip(id);
        if (result) {
            System.out.println("Ship has been docked");
        } else {
            System.out.println("Ship not found");
        }
    }

}
