package com.senla.testproject.ui;

import java.util.Scanner;

public class ConsoleInitializer {
    UserInputManager inputManager = new UserInputManager();

    public void run() {
        boolean consoleFlag = true;
        while (consoleFlag) {
            System.out.println("\nEnter command (9 for help): ");
            String result = inputManager.processUserInput(getUserInput());
            if (result.equals("exit")) {
                consoleFlag = false;
            }
            if (result.equals("help")) {
                this.showOptions();
            }
        }
    }

    private void showOptions() {
        System.out.println("\nEnter number of the command: \n1. Create ship\n2. Check storaged water\n3. Print docked ships\n4. Print sailing ships\n5. Dock ship\n6. Demolish ship\n9. Print help\n0. Exit program");
    }

    private int getUserInput() {
        Scanner in = new Scanner(System.in);
        String commandInput = in.nextLine();
        int command = Integer.parseInt(commandInput);
        return command;
    }
}
