package com.company;

import java.util.Random;

public class Core {
    public void core() {
    Task1(returnInt());
    Task2(returnInt(), returnInt(), returnInt());
    Task3(returnInt(), returnInt(), returnInt());
    Task4(returnInt());
}

    private int returnInt() {
        Random rand = new Random();
        return rand.nextInt((999 - 100) + 1) + 100;
    }

    private void Task1(int num) {
        System.out.printf("~~~~~~~~~~~TASK 1~~~~~~~~~~~ \nRandom integer: %d", num);
        int max;
        if (num/100 >= (num/10)%10 && num/100 >= num%10) {
            max = num/100;
        } else if ((num/10)%10 >= num/100 && (num/10)%10 >= num%10) {
            max = (num/10)%10;
        } else {
            max = num%10;
        }
        System.out.printf("\nMaximum digit: %d\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", max);
    }

    private void Task2(int one, int two, int three) {
        System.out.printf("~~~~~~~~~~~TASK 2~~~~~~~~~~~ \nRandom integers: %d, %d, %d", one, two, three);
        System.out.printf("\nSum of their first digits: %d\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", (one/100+two/100+three/100));
    }

    private void Task3(int one, int two, int three) {
        System.out.printf("~~~~~~~~~~~TASK 3~~~~~~~~~~~ \nRandom integers: %d, %d, %d", one, two, three);
        System.out.printf("\nStrange result: %d\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", (one*1000+two-three));
    }

    private void Task4(int num) {
        System.out.printf("~~~~~~~~~~~TASK 4~~~~~~~~~~~ \nRandom integer: %d", num);
        System.out.printf("\nSum of it's digits: %d\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", (num/100+(num/10)%10+num%10));
    }
}
