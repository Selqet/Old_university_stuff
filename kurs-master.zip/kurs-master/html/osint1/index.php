<?php
$flag = "";
$flag_err = "";
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["flag"]))){
        $flag_err = "Пожалуйста, введите флаг";
    } else{
        $flag = trim($_POST["flag"]);
        if ($flag == "mightyshield1776") {
            echo "Да, все верно";
        } else {
            echo "Неправильный флаг";
        }
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OSINT</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <br> <br>
    Первое задание довольно простое: нужно узнать пароль от рабочей почты этого человека
    <br> <br>
    <img src="./task1.jpg" width="600" height="400">
    <div class="wrapper">
        <?php 
        if(!empty($flag_err)){
            echo '<div class="alert alert-danger">' . $flag_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label> Введите флаг </label>
                <input type="text" name="flag" class="form-control <?php echo (!empty($flag_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $flag; ?>">
                <span class="invalid-feedback"><?php echo $flag_err; ?></span>
            </div>    
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Ввести">
            </div>
        </form>
    </div>
    <br> <br>
    <details>
    <summary>Подсказка</summary>
    В сегодняшнее время довольно часто можно увидеть истории, когда случайное фото сделало секретную информацию достоянием общественности.
    <br>
    Внимательно присмотритесь к картинке
</details>
</body>
</html>