<?php
$flag = "";
$flag_err = "";
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["flag"]))){
        $flag_err = "Пожалуйста, введите флаг";
    } else{
        $flag = trim($_POST["flag"]);
        if ($flag == "Microsoft San-Jose") {
            echo "Да, все верно";
        } else {
            echo "Неправильный флаг";
        }
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OSINT</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <br> <br>
    Теперь Вам предстоит узнать, кому принадлежит IP <b> 52.239.28.85 </b> и где он расположен.
    <br> <br>
    Введите через пробел два слова с заглавной буквы: провайдера и город
    <br> <br>
    <div class="wrapper">
        <?php 
        if(!empty($flag_err)){
            echo '<div class="alert alert-danger">' . $flag_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label> Введите флаг </label>
                <input type="text" name="flag" class="form-control <?php echo (!empty($flag_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $flag; ?>">
                <span class="invalid-feedback"><?php echo $flag_err; ?></span>
            </div>    
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Ввести">
            </div>
        </form>
    </div>
    <br> <br>
    <details>
    <summary>Подсказка</summary>
    Данное задание развивает такой необходимый навык, как сбор сведений об IP адресе.
    <br>
    Существует множество сервисов, позволяющих получить подобную информацию. Один из них -- 2IP (https://2ip.ru/whois/)
</details>
</body>
</html>