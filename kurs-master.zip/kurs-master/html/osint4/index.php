<?php
$flag = "";
$flag_err = "";
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["flag"]))){
        $flag_err = "Пожалуйста, введите флаг";
    } else{
        $flag = trim($_POST["flag"]);
        if ($flag == "LEVC November") {
            echo "Да, все верно";
        } else {
            echo "Неправильный флаг";
        }
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OSINT</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <br> <br>
    В интернете можно найти очень много информации по конкретному автомобилю, если знать, где искать
    <br> <br>
    Введите марку и месяц первой регистрации автомобиля на фотографии (например, 'BMW June')
    <br> <br>
    <img src="./car.jpg" width="600" height="400">
    <div class="wrapper">
        <?php 
        if(!empty($flag_err)){
            echo '<div class="alert alert-danger">' . $flag_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label> Введите флаг </label>
                <input type="text" name="flag" class="form-control <?php echo (!empty($flag_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $flag; ?>">
                <span class="invalid-feedback"><?php echo $flag_err; ?></span>
            </div>    
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Ввести">
            </div>
        </form>
    </div>
    <details>
        <summary>Подсказка</summary>
        Во многих странах любой человек может узнать информацию о регистрации, владельце,
        <br>
        модели автомобиля, городе или почтовом индексе, зная только автомобильный номер.
        <br>
        Да, такая информация действительно много где является публичной. Для автомобилей, зарегистрированных
        <br>
        в Великобритании ее можно узнать, например, на официальном вебсайте vehicleenquiry.service.gov.uk
    </details>
</body>
</html>