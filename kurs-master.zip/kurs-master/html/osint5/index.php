<?php
$flag = "";
$flag_err = "";
 
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["flag"]))){
        $flag_err = "Пожалуйста, введите флаг";
    } else{
        $flag = trim($_POST["flag"]);
        if ($flag == "Berlin May") {
            echo "Да, все верно";
        } else {
            echo "Неправильный флаг";
        }
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OSINT</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <br> <br>
    Это задание будет самым 'простым'. Всего-то нужно найти место и время фотографии.
    <br> <br>
    Введите город и месяц фотографии (например, 'London June')
    <br> <br>
    <img src="./demonstration.png" width="600" height="400">
    <div class="wrapper">
        <?php 
        if(!empty($flag_err)){
            echo '<div class="alert alert-danger">' . $flag_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label> Введите флаг </label>
                <input type="text" name="flag" class="form-control <?php echo (!empty($flag_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $flag; ?>">
                <span class="invalid-feedback"><?php echo $flag_err; ?></span>
            </div>    
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Ввести">
            </div>
        </form>
    </div>
    <details>
    <summary>Подсказка</summary>
    Это задание действительно неочевидное
    <br> <br>
    Для того, чтобы понять, что это за место, можно просто поискать по картинке в браузере.
    <br>
    Google Images ничего не найдет, а вот Яндекс.Картинки узнает автовокзал в Берлине.
    <br>
    Также можно загуглить граффити: 'love hurts unicorn' и выйти на первоисточник -- это довольно популярная серия граффити. 
    <br>
    Еще можно рассмотреть табличку главного отеля или малозаметные надписи на немецком. 
    <br> <br>
    С определением времени все интереснее. На заднем фоне можно рассмотреть демонстрацию. 
    <br>
    Если хорошо знать географию или просто погуглить, то можно узнать палестинский флаг. 
    <br>
    Если же следить за политикой или снова погуглить, то можно понять, что демонстрация приурочена к Израильско-Палестинским событиям 2021 года. 
    <br>
    Википедия говорит, что демонстрации проходили с мая по июнь 2021 года. В Германии -- в середине мая.
</details>
</body>
</html>