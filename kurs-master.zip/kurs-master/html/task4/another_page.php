<!DOCTYPE html>
<html>
<body>
flag-task4
</body>
</html>
<?php
if (isset($_REQUEST['message'])) {    
    header("Location: ./index.php?message=fail", true, 301);
    exit();
}
header("Location: ./index.php", true, 301);
exit();
?>