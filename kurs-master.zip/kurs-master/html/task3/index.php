<!DOCTYPE html>
<html>
<head>
    <title>Web</title>
</head>
<body>
I've got a little headache...
<?php
header('flag: flag-task3')
?>
<br> <br>
<details>
    <summary>Подсказка</summary>
    Заголовки HTTP (headers) — это строки в HTTP-сообщении, содержащие разделенную двоеточием пару имя-значение.
    <br>
    Для анализа заголовков HTTP достаточно использовать Панель разработчика любого браузера (Клавиша F12).
</details>
</body>
</html> 